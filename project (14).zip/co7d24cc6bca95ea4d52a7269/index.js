let inputEl = document.getElementById("inputel")
let convertBtn = document.getElementById("convertbtn")
let convertElOne = document.getElementById("convertelone")
let convertElTwo = document.getElementById("converteltwo")
let convertElThree = document.getElementById("convertelthree")

convertBtn.addEventListener("click", function() {
    let feet = inputEl.value *17425
    let meter = inputEl.value /17425
    convertElOne.textContent = `${ inputEl.value} BTC = ${feet.toFixed(2)} USD | ${inputEl.value}  USD = ${meter.toFixed(7)} BTC`
         let liters = inputEl.value * 1270
             let gallon = inputEl.value / 1270
                 convertElTwo.textContent = `${ inputEl.value} ETH = ${liters.toFixed(2)}  USD| ${inputEl.value} USD = ${gallon.toFixed(5)} ETH`
             let kilo = inputEl.value * 70
        let pound = inputEl.value / 70
    convertElThree.textContent = `${ inputEl.value} LTC = ${kilo.toFixed(2)} USD | ${inputEl.value} USD = ${pound.toFixed(2)} LTC`
})

/*
when the converbtn is click the data in the input element changes the psto what ever number is put in the input of the opposing measurement so if 20 then everything gets channged to how ever many of it is versus how much it would be in the opposiute mesurement
1 meter = 17425
1 liter = 1300 gallon
1 kilogram = 76 pound
*/